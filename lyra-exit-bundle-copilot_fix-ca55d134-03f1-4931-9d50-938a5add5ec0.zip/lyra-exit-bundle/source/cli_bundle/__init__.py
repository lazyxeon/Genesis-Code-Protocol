"""CLI utilities for the Genesis Code Protocol."""
