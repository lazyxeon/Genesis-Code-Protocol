---
name: Security report (DO NOT USE)
about: Please DO NOT disclose vulnerabilities here; follow SECURITY.md
labels: security
---

Please do not disclose vulnerabilities via public issues.
See **SECURITY.md** for private reporting instructions.
