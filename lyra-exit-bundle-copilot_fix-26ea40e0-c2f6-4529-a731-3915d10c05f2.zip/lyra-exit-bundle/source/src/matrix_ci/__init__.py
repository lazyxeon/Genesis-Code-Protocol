"""Matrix CI pipeline module."""
