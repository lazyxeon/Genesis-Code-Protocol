#include "util.hpp"
#include "math.hpp"
int touch_all(){ return sum({1,2,3}); }
